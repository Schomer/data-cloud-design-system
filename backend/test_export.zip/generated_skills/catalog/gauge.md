---
name: gauge
category: visualizations
description: Specialized gauge for domain-specific insights
intent_keywords: ["specialized", "network", "logic", "performance", "gauge"]
schema: nodes: array, links: array, metrics: string[]
---

# Gauge Skill

## Visual Specifications
```json
{
  "palette": [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b"
  ]
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: specialized, network, logic, performance.
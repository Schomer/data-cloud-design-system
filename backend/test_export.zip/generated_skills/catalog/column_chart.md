---
name: column_chart
category: visualizations
description: Standard column chart for column comparisons
intent_keywords: ["column", "chart", "viz", "plot"]
schema: data: array, axes: object
---

# Column Chart Skill

## Visual Specifications
```json
{
  "palette": [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b"
  ]
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: column, chart, viz, plot.
---
name: overlays
category: components
description: Dialogs, Modals, and Popover containers
intent_keywords: ["modal", "dialog", "overlay", "popup"]
schema: title: string, isOpen: boolean, children: any
---

# Modals & Overlays Skill

## Visual Specifications
```json
{
  "bg": "#ffffff",
  "darkBg": "#1a1a1a",
  "borderColor": "#e2e8f0",
  "darkBorderColor": "#1e293b",
  "borderRadius": 12,
  "title": "Overlay Modal"
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: modal, dialog, overlay, popup.
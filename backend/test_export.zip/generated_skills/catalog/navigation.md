---
name: navigation
category: components
description: Sidebar and Top-bar navigation items
intent_keywords: ["nav", "menu", "sidebar", "link", "active"]
schema: items: array, activeId: string
---

# Navigation Systems Skill

## Visual Specifications
```json
{
  "activeText": "#2563eb",
  "darkActiveText": "#60a5fa",
  "activeBorder": "#3b82f6",
  "inactiveText": "#64748b",
  "darkInactiveText": "#cbd5e1",
  "hoverText": "#334155",
  "darkHoverText": "#e2e8f0",
  "defaultText": "Nav Item"
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: nav, menu, sidebar, link.
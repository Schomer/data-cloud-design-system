---
name: button
category: components
description: Primary, Secondary, Destructive, and Ghost action triggers
intent_keywords: ["click", "submit", "action", "trigger", "button"]
schema: label: string, variant: 'primary'|'secondary'|'destructive'|'ghost', disabled: boolean
---

# Button Skill

## Visual Specifications
```json
{
  "primaryBg": "#5aa1d8",
  "primaryHoverBg": "#047857",
  "primaryText": "#000000",
  "primaryLabel": "Primary Action",
  "secondaryBg": "#ffffff",
  "secondaryHoverBg": "#f8fafc",
  "secondaryDarkBg": "#262626",
  "secondaryDarkHoverBg": "#1e293b",
  "secondaryText": "#334155",
  "secondaryDarkText": "#e2e8f0",
  "secondaryBorder": "#e2e8f0",
  "secondaryDarkBorder": "#334155",
  "secondaryLabel": "Secondary",
  "destructiveBg": "#e11d48",
  "destructiveHoverBg": "#be123c",
  "destructiveText": "#ffffff",
  "destructiveLabel": "Destructive",
  "ghostText": "#2563eb",
  "ghostDarkText": "#60a5fa",
  "ghostHoverBg": "#eff6ff",
  "ghostDarkHoverBg": "#1e3a8a",
  "ghostLabel": "Ghost Button",
  "borderRadius": 8,
  "paddingX": 16,
  "paddingY": 8,
  "fontWeight": "500"
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: click, submit, action, trigger.
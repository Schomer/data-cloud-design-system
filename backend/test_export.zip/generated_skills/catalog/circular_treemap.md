---
name: circular_treemap
category: visualizations
description: Circular Treemap for part-to-whole or hierarchical breakdown
intent_keywords: ["proportions", "hierarchy", "flow", "nested", "circular"]
schema: children: array, value: number
---

# Circular Treemap Skill

## Visual Specifications
```json
{
  "palette": [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b"
  ]
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: proportions, hierarchy, flow, nested.
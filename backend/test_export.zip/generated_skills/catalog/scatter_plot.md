---
name: scatter_plot
category: visualizations
description: Standard scatter plot for scatter comparisons
intent_keywords: ["scatter", "chart", "viz", "plot"]
schema: data: array, axes: object
---

# Scatter Plot Skill

## Visual Specifications
```json
{
  "palette": [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b"
  ]
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: scatter, chart, viz, plot.
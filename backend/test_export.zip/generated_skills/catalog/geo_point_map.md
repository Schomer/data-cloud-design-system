---
name: geo_point_map
category: visualizations
description: Geographic geo point map for spatial data
intent_keywords: ["map", "geo", "spatial", "location", "geo"]
schema: region: string, value: number
---

# Geo Point Map Skill

## Visual Specifications
```json
{
  "palette": [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b"
  ]
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: map, geo, spatial, location.
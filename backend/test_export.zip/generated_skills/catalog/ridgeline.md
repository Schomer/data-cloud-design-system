---
name: ridgeline
category: visualizations
description: Ridgeline for temporal trends and sequences
intent_keywords: ["time", "sequence", "timeline", "trend", "ridgeline"]
schema: timestamp: string, value: number
---

# Ridgeline Skill

## Visual Specifications
```json
{
  "palette": [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b"
  ]
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: time, sequence, timeline, trend.
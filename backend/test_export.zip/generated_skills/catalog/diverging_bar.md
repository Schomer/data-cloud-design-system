---
name: diverging_bar
category: visualizations
description: Diverging Bar for statistical distribution and variance
intent_keywords: ["distribution", "variance", "spread", "diverging"]
schema: ranges: array, frequency: numeric[]
---

# Diverging Bar Skill

## Visual Specifications
```json
{
  "palette": [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b"
  ]
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: distribution, variance, spread, diverging.
---
name: input_fields
category: components
description: Text, Number, Email, and Search input controls
intent_keywords: ["text", "input", "form", "search", "field", "type"]
schema: label: string, placeholder: string, value: string, type: string
---

# Input Fields Skill

## Visual Specifications
```json
{
  "bg": "#ffffff",
  "darkBg": "#121212",
  "borderColor": "#e2e8f0",
  "darkBorderColor": "#1e293b",
  "borderRadius": 8,
  "paddingX": 12,
  "paddingY": 8,
  "placeholder": "Enter text..."
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: text, input, form, search.
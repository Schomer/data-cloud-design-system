---
name: cards_kpi
category: components
description: Visual containers for high-level metrics and summaries
intent_keywords: ["metric", "kpi", "card", "summary", "stat"]
schema: title: string, value: string|number, trend: number
---

# KPI Cards Skill

## Visual Specifications
```json
{
  "bg": "#ffffff",
  "darkBg": "#1a1a1a",
  "borderColor": "#e2e8f0",
  "darkBorderColor": "#1e293b",
  "borderRadius": 12,
  "padding": 20,
  "titleColor": "#64748b",
  "darkTitleColor": "#94a3b8",
  "valueColor": "#0f172a",
  "darkValueColor": "#3b82f6",
  "defaultTitle": "KPI Metric"
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: metric, kpi, card, summary.
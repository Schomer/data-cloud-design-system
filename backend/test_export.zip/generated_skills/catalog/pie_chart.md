---
name: pie_chart
category: visualizations
description: Standard pie chart for pie comparisons
intent_keywords: ["pie", "chart", "viz", "plot"]
schema: data: array, axes: object
---

# Pie Chart Skill

## Visual Specifications
```json
{
  "palette": [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b"
  ]
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: pie, chart, viz, plot.
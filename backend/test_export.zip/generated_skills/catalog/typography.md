---
name: typography
category: components
description: Full sizing and weight scale for H1-H6 and Body text
intent_keywords: ["font", "text", "heading", "body", "size", "weight"]
schema: variant: string, children: string
---

# Typography System Skill

## Visual Specifications
```json
{
  "h1": {
    "fontSize": 36,
    "fontWeight": "800",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#0f172a",
    "darkColor": "#f8fafc",
    "letterSpacing": "-0.025em",
    "lineHeight": "1",
    "content": "Display Headline"
  },
  "h2": {
    "fontSize": 30,
    "fontWeight": "700",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#0f172a",
    "darkColor": "#f8fafc",
    "letterSpacing": "-0.025em",
    "lineHeight": "1.25",
    "content": "Page Title"
  },
  "h3": {
    "fontSize": 24,
    "fontWeight": "600",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#0f172a",
    "darkColor": "#f8fafc",
    "letterSpacing": "-0.025em",
    "lineHeight": "1.375",
    "content": "Section Header"
  },
  "h4": {
    "fontSize": 20,
    "fontWeight": "600",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#0f172a",
    "darkColor": "#f8fafc",
    "letterSpacing": "-0.025em",
    "lineHeight": "1.375",
    "content": "Card Title"
  },
  "h5": {
    "fontSize": 18,
    "fontWeight": "500",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#0f172a",
    "darkColor": "#f8fafc",
    "letterSpacing": "-0.025em",
    "lineHeight": "1.375",
    "content": "Subsection"
  },
  "h6": {
    "fontSize": 14,
    "fontWeight": "600",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#64748b",
    "darkColor": "#94a3b8",
    "letterSpacing": "0.05em",
    "lineHeight": "1.375",
    "textTransform": "uppercase",
    "content": "Subtitle"
  },
  "bodyBase": {
    "fontSize": 16,
    "fontWeight": "400",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#334155",
    "darkColor": "#cbd5e1",
    "letterSpacing": "normal",
    "lineHeight": "1.625",
    "content": "The quick brown fox jumps over the lazy dog. This base text size is used for primary article content, long descriptions, or modal body text. It offers the best readability for long-form reading."
  },
  "bodySmall": {
    "fontSize": 14,
    "fontWeight": "400",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#475569",
    "darkColor": "#94a3b8",
    "letterSpacing": "normal",
    "lineHeight": "1.625",
    "content": "The quick brown fox jumps over the lazy dog. Small text is commonly used for data table rows, secondary descriptions, or UI element labels where space is tighter."
  },
  "bodyXs": {
    "fontSize": 12,
    "fontWeight": "400",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#64748b",
    "darkColor": "#64748b",
    "letterSpacing": "normal",
    "lineHeight": "1.5",
    "content": "The quick brown fox jumps over the lazy dog. Extra small text is reserved for metadata, timestamps, chart axis labels, and subtle helper text below inputs."
  },
  "mono": {
    "fontSize": 14,
    "fontWeight": "400",
    "fontFamily": "monospace",
    "color": "#1e293b",
    "darkColor": "#e2e8f0",
    "bg": "#f1f5f9",
    "darkBg": "#1e293b",
    "letterSpacing": "normal",
    "lineHeight": "1.5",
    "content": "UUID-8472-A9F3-XYZ"
  },
  "metric": {
    "fontSize": 36,
    "fontWeight": "600",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#2563eb",
    "darkColor": "#60a5fa",
    "letterSpacing": "-0.05em",
    "lineHeight": "1",
    "content": "$24.5M"
  },
  "muted": {
    "fontSize": 14,
    "fontWeight": "400",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#94a3b8",
    "darkColor": "#64748b",
    "fontStyle": "italic",
    "letterSpacing": "normal",
    "lineHeight": "1.5",
    "content": "No data available for the selected period."
  },
  "kpiTitle": {
    "fontSize": 14,
    "fontWeight": "500",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#64748b",
    "darkColor": "#94a3b8",
    "letterSpacing": "normal",
    "lineHeight": "1.25",
    "content": "Total Revenue"
  },
  "kpiValue": {
    "fontSize": 30,
    "fontWeight": "600",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#0f172a",
    "darkColor": "#f8fafc",
    "letterSpacing": "-0.025em",
    "lineHeight": "1.25",
    "content": "$124.5k"
  },
  "buttonText": {
    "fontSize": 14,
    "fontWeight": "500",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#ffffff",
    "darkColor": "#ffffff",
    "letterSpacing": "normal",
    "lineHeight": "1.25",
    "content": "Primary Action"
  },
  "navText": {
    "fontSize": 14,
    "fontWeight": "500",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#64748b",
    "darkColor": "#94a3b8",
    "letterSpacing": "normal",
    "lineHeight": "1.25",
    "content": "Dashboard Home"
  },
  "tooltipText": {
    "fontSize": 12,
    "fontWeight": "400",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#0f172a",
    "darkColor": "#f8fafc",
    "letterSpacing": "normal",
    "lineHeight": "1.5",
    "content": "Last updated 2 hours ago"
  },
  "tableHeader": {
    "fontSize": 12,
    "fontWeight": "600",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#64748b",
    "darkColor": "#94a3b8",
    "textTransform": "uppercase",
    "letterSpacing": "0.05em",
    "lineHeight": "1",
    "content": "Transaction Type"
  },
  "tableRow": {
    "fontSize": 14,
    "fontWeight": "400",
    "fontFamily": "\"Inter\", sans-serif",
    "color": "#0f172a",
    "darkColor": "#cbd5e1",
    "letterSpacing": "normal",
    "lineHeight": "1.25",
    "content": "Payment sent to vendor"
  }
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: font, text, heading, body.
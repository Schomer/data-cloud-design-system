---
name: data_table
category: components
description: Detailed grid for records with sorting and search
intent_keywords: ["table", "grid", "list", "rows", "records"]
schema: columns: array, data: array
---

# Data Table Skill

## Visual Specifications
```json
{
  "bg": "#ffffff",
  "darkBg": "#1a1a1a",
  "borderColor": "#e2e8f0",
  "darkBorderColor": "#1e293b",
  "headerText": "#64748b",
  "darkHeaderText": "#94a3b8",
  "rowText": "#0f172a",
  "darkRowText": "#cbd5e1",
  "rowBorder": "#f1f5f9",
  "darkRowBorder": "#262626",
  "borderRadius": 12,
  "headerContent": "Column Header"
}
```

## Recommended Implementation Pattern
This component should be rendered using the JTC Design System guidelines. 
It inherits global themes from `theme_manifest.json`.

## Usage Context
Commonly used for: table, grid, list, rows.
---
name: discovery_router
description: Maps user intents to specific visualization and UI skills across the expanded JTC catalog
---

# Intent Router

| Intent Category | Keywords | Skill File |
|---|---|---|
| Components | click / submit / action | catalog/button.md |
| Components | text / input / form | catalog/input_fields.md |
| Components | checkbox / radio / toggle | catalog/selection_controls.md |
| Components | metric / kpi / card | catalog/cards_kpi.md |
| Components | table / grid / list | catalog/data_table.md |
| Components | nav / menu / sidebar | catalog/navigation.md |
| Components | modal / dialog / overlay | catalog/overlays.md |
| Components | font / text / heading | catalog/typography.md |
| Visualizations | line / chart / viz | catalog/line_chart.md |
| Visualizations | area / chart / viz | catalog/area_chart.md |
| Visualizations | column / chart / viz | catalog/column_chart.md |
| Visualizations | bar / chart / viz | catalog/bar_chart.md |
| Visualizations | pie / chart / viz | catalog/pie_chart.md |
| Visualizations | donut / chart / viz | catalog/donut_chart.md |
| Visualizations | scatter / chart / viz | catalog/scatter_plot.md |
| Visualizations | distribution / variance / spread | catalog/histogram.md |
| Visualizations | distribution / variance / spread | catalog/density_plot.md |
| Visualizations | distribution / variance / spread | catalog/boxplot.md |
| Visualizations | distribution / variance / spread | catalog/pyramid.md |
| Visualizations | distribution / variance / spread | catalog/diverging_bar.md |
| Visualizations | distribution / variance / spread | catalog/heatmap.md |
| Visualizations | distribution / variance / spread | catalog/hexbin.md |
| Visualizations | map / geo / spatial | catalog/world_map.md |
| Visualizations | map / geo / spatial | catalog/usa_map.md |
| Visualizations | map / geo / spatial | catalog/geo_point_map.md |
| Visualizations | map / geo / spatial | catalog/tile_map.md |
| Visualizations | proportions / hierarchy / flow | catalog/sankey.md |
| Visualizations | proportions / hierarchy / flow | catalog/treemap.md |
| Visualizations | proportions / hierarchy / flow | catalog/sunburst.md |
| Visualizations | proportions / hierarchy / flow | catalog/funnel.md |
| Visualizations | proportions / hierarchy / flow | catalog/waffle.md |
| Visualizations | proportions / hierarchy / flow | catalog/pictogram.md |
| Visualizations | proportions / hierarchy / flow | catalog/trellis.md |
| Visualizations | proportions / hierarchy / flow | catalog/circular_treemap.md |
| Visualizations | specialized / network / logic | catalog/gauge.md |
| Visualizations | specialized / network / logic | catalog/radar.md |
| Visualizations | specialized / network / logic | catalog/network_graph.md |
| Visualizations | specialized / network / logic | catalog/workflow_diagram.md |
| Visualizations | specialized / network / logic | catalog/quadrant_chart.md |
| Visualizations | time / sequence / timeline | catalog/candlestick.md |
| Visualizations | time / sequence / timeline | catalog/sparkline.md |
| Visualizations | time / sequence / timeline | catalog/event_timeline.md |
| Visualizations | time / sequence / timeline | catalog/ridgeline.md |
| Visualizations | time / sequence / timeline | catalog/horizon_chart.md |